create database estacionamento;
use estacionamento;

create table cliente(
	cpf int primary key not null,
    nome varchar(60),
    dtNasc date
);

create table modelo (
	codMod int primary key not null,
    desc_2 varchar(40)
);

create table patio (
	num int primary key auto_increment,
    ender varchar(40),
    capacidade int
);

create table veiculo (
	placa varchar(8) primary key auto_increment,
    modelo_codmod int,
    cliente_cpf int,
    cor varchar(20),
    ano int(4),
    constraint fk_mod foreign key veiculo(modelo_codmod) references modelo(codMod),
    constraint fk_cpf foreign key veiculo(cliente_cpf) references cliente(cpf)
);

create table estaciona(
	cod int primary key auto_increment,
    dtEntrada date,
    dtSaida date,
    hsEntrada time,
    hsSaida time,
    patio_num int,
    veiculo_placa varchar(8),
    constraint fk_patio foreign key estaciona(patio_num) references patio(num),
    constraint fk_placa foreign key estaciona(veiculo_placa) references veiculo(placa)
);

insert into cliente values (123321321, 'Luiz Cláudio', '1983-06-08'), 
(234124242, 'Marcio Campos', '1972-08-07'), 
(731315271, 'João Batista', '1981-06-05'),
(323131131, 'Juliana Marques', '1982-04-02'),
(432242321, 'Fernanda Veiga', '1987-03-01');

insert into veiculo values ('JJJ-2020', 2, 123321321, 'branco', 1998),
('KMK-1020', 3, 323131131, 'preto', 2000),
('BOY-9898', 2, 432242321, 'azul metálico', 2009),
('SPS-1131', 1, 234124242, 'vinho', 1998),
('JEG-1010', 2, 731315271, 'prata', 2001);

insert into modelo values (1, 'SEDAN'), (2, 'HATCH'), (3, 'WAGON');

insert into patio values (1, 'Rua K', 5), (2, 'Rua L', 4), (3, 'Rua J', 6);

insert into estaciona (cod, patio_num, veiculo_placa, dtEntrada, dtSaida, hsEntrada, hsSaida) values (1, 3, 'JJJ-2020', '2023-03-02', '2023-03-02', '14:30', '16:00'),
(2, 2, 'KMK-1020', '2023-04-01', '2023-04-02', '12:00', '07:00'),
(3, 2, 'BOY-9898', '2023-05-10', '2023-05-10', '13:00', '14:00'),
(4, 1, 'SPS-1131', '2023-03-10', '2023-03-10', '08:00', '08:20'),
(5, 3, 'JEG-1010', '2023-02-07', '2023-02-10', '12:00', '17:35');

select a.nome, b.placa from cliente a inner join veiculo b on a.cpf = b.cliente_cpf;

select a.cpf, a.nome from cliente a inner join veiculo b on a.cpf = b.cliente_cpf where b.placa = 'JJJ-2020';

select placa, cor from veiculo a inner join estaciona b on a.placa = b.veiculo_placa where b.cod = 1;

select placa, ano from veiculo a inner join estaciona b on a.placa = b.veiculo_placa where b.cod = 3;

select placa, ano, desc_2 from veiculo a inner join modelo b on a.modelo_codMod = b.codMod and ano > 2000;

select ender, dtEntrada, dtSaida from patio a inner join estaciona b on a.num = b.patio_num inner join veiculo c on b.veiculo_placa = c.placa where c.placa = 'JEG-1010';

select count(*) from estaciona a inner join veiculo b on a.veiculo_placa = b.placa where b.cor = 'vinho';

select nome from cliente a inner join veiculo b on a.cpf = b.cliente_cpf where b.modelo_codmod = 1;

select veiculo_placa, a.hsEntrada, a.hsSaida from estaciona a inner join veiculo b on a.veiculo_placa = b.placa where b.cor = 'preto';

select dtEntrada, hsEntrada, dtSaida, hsSaida from estaciona a inner join veiculo b on a.veiculo_placa = b.placa where b.placa = 'JJJ-2020';

select nome from cliente a inner join veiculo b on a.cpf = b.cliente_cpf inner join estaciona c on c.veiculo_placa = b.placa where c.cod = 2;

select cpf from cliente a inner join veiculo b on a.cpf = b.cliente_cpf inner join estaciona c on c.veiculo_placa = b.placa where c.cod = 3;

select desc_2 from modelo a inner join veiculo b on a.codMod = b.modelo_codMod inner join estaciona c on b.placa = c.veiculo_placa where c.cod = 2;

select placa, nome, desc_2 from cliente a inner join veiculo b on a.cpf = b.cliente_cpf inner join modelo c on b.modelo_codMod = c.codMod;


