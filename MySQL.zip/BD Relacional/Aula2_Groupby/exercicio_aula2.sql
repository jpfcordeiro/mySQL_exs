create database empresa_exerc;
use empresa_exerc;

create table funcionario(
matricula int primary key,
nome_func varchar(50),
dataServico date,
salario double,
cod_orgao int
);

create table departamento(
cod_depto int primary key auto_increment,
localizacao varchar(30),
nome_depto varchar(35));

alter table funcionario add constraint fk_orgao foreign key (cod_orgao) references departamento(cod_depto);

insert into departamento(localizacao, nome_depto) values ('Setor 2', 'Financeiro'), ('Setor 2', 'Recursos Humanos'), ('Setor 5', 'Informática');

insert into funcionario values (10, 'João', '2023-01-21', 2500, 1), (5, 'Rafael', '2022-02-24', 1000, 2), (3, 'Iza', '2022-08-11', 1500, 1);

select * from funcionario order by matricula;

select count(*) from funcionario;

insert into funcionario values (15, 'Vinicius', '1986-01-20', 1400, 3);

select *, year(CURDATE()) - year(dataServico) from funcionario where year(CURDATE()) - year(dataServico) >= 10 and year(CURDATE()) - year(dataServico) <= 12;

select nome_func, matricula, salario from funcionario where salario = 1000;

select * from funcionario where year(CURDATE()) - year(dataServico) = 5;

select matricula, nome_func, salario from funcionario order by nome_func;

select nome_func, matricula, salario, year(curdate()) - year(dataServico) as anos_servico from funcionario order by year(curdate()) - year(dataServico) desc;

select max(salario) from funcionario;

select avg(salario) from funcionario;

select min(salario) from funcionario;

select matricula, nome_func, nome_depto from funcionario a, departamento b where a.cod_orgao = b.cod_depto;

select sum(salario) from funcionario;

select a.nome_func from funcionario a, departamento b where a.cod_orgao = b.cod_depto and nome_depto = 'Recursos Humanos' group by b.cod_depto;

select matricula, min(salario) from funcionario a where cod_orgao = 222 group by cod_orgao;

select matricula, min(salario) from funcionario a where cod_orgao = 333 group by cod_orgao;

select min(salario), max(salario) from funcionario group by matricula;

select max(salario) from funcionario where dataServico >= '2004-03' group by cod_orgao;

select cod_orgao, avg(salario) from funcionario group by cod_orgao having avg(salario) > 560;

select max(salario) from funcionario group by cod_orgao having count(*) > 3;

select a.nome_func, a.salario * b.count from funcionario a, (select count(*) as count from funcionario) b group by a.nome_func;




