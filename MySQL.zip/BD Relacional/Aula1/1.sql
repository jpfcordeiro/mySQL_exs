create database escola; 
use escola;
create table displina (
	id_disciplina int(5) not null auto_increment primary key,
    nome_disciplina varchar(40),
    nome_professor varchar(60)
);

create table aluno_disciplina (
	matricula int not null primary key,
    nome_aluno varchar(60),
    sexo char(1),
    endereco varchar(50)
);

rename table displina to disciplina;

alter table disciplina add column qtd_horas int;

alter table disciplina change qtd_horas qtd_hora int;

alter table aluno_disciplina add column id_disciplina int(5);

alter table aluno_disciplina add constraint fk_idAluno foreign key(id_disciplina) references disciplina(id_disciplina); 

insert into disciplina(nome_disciplina, nome_professor, qtd_hora) values ('Bando de Dados II', 'Luiz', 60), ('Redes', 'Diego', 50),
('Algoritmos', 'Ramon', 70);

insert into aluno_disciplina(matricula, nome_aluno, sexo, endereco, id_disciplina) values (1, 'José', 'M', 'Rua Um', 1), (2, 'Fabio', 'M', 'Rua Dois', 2),
(3, 'Taina', 'F', 'Rua Três', 3);

update aluno_disciplina set nome_aluno = 'Fernando' where matricula = 1;

update aluno_disciplina set endereco = 'Rua Juquiá' where matricula = 3;

delete from aluno_disciplina where matricula = 3;

delete from disciplina where id_disciplina = 3;

alter table aluno_disciplina drop column endereco;

select * from aluno_disciplina;

drop table aluno_disciplina;

delete from disciplina;