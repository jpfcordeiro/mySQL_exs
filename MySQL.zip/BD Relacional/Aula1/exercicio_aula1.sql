create database clinica;

use clinica;

create table ambulatorios (
	nroa int primary key not null, 
	andar numeric(3) not null,
	capacidade smallint
);

create table medicos (
	codm int primary key not null,
    nome varchar(40) not null,
    idade smallint not null,
    especialidade varchar(20),
    cpf numeric(11) not null unique,
    cidade varchar(30)
);

create table pacientes (
	codp int primary key not null,
    nome varchar(40) not null, 
    idade smallint not null,
    cidade varchar(30),
    cpf numeric(11) not null unique,
    doenca varchar(40) not null
);

create table funcionarios (
	codf int primary key not null,
    nome varchar(40) not null,
    idade smallint,
    cpf numeric(11) not null unique,
    cidade varchar(30),
    salario decimal(10,2),
    cargo varchar(20)
);

create table consultas (
	codm int,
    codp int,
    dataCons date,
    hora time,
    constraint fk_pacientes foreign key(codp) references pacientes(codp),
    constraint fk_medicoss foreign key(codm) references medicos(codm)
);

alter table medicos add column nroa int;
alter table medicos add constraint fk_medicos foreign key(nroa) references ambulatorios(nroa);

insert into ambulatorios (nroa, andar, capacidade) values (1, 1, 30), (2, 1, 50), (3, 2, 40);

insert into pacientes (codp, nome, idade, cidade, cpf, doenca) values (1, 'Ana', 20, 'Florianópolis', 20000200000, 'Gripe'),
(2, 'Paulo', 24, 'Palhoca', 20000220000, 'Fratura'),
(3, 'Lucia', 30, 'Biguacu', 22000200000, 'Tendinite'),
(4, 'Carlos', 28, 'Joinville', 11000110000, 'Sarampo');

insert into medicos (codm, nome ,idade, especialidade, cpf, cidade, nroa) values (1, 'Joao', 40, 'Ortopedia', 10000100000, 'Florianópolis', 1),
(2, 'Maria', 42, 'Traumatologia', 10000110000, 'Blumenau', 2),
(3, 'Pedro', 51, 'Pediatria', 11000100000, 'São José', 2),
(4, 'Carlos', 28, 'Ortopedia', 11000110000, 'Joinville', 1),
(5, 'Marcia', 3, 'Neurologia', 11000111000, 'Biguacu', 3);

insert into funcionarios (codf, nome, idade, cidade, salario, cpf) values (1, 'Rita', 32, 'São José', 1200, 20000100000),
(2, 'Maria', 55, 'São José', 1220, 30000110000),
(3, 'Caio', 45, 'Florianópolis', 1100, 41000100000),
(4, 'Carlos', 44, 'Florianópolis', 1200, 51000110000),
(5, 'Paula', 33, 'Florianópolis', 2500, 61000111000);

insert into consultas (codm, codp, dataCons, hora) values 
(1, 1, '2022-06-12', '14:00'),
(1, 4, '2022-06-13', '10:00'),
(3, 3, '2023-02-12', '10:00'),
(3, 4, '2023-06-19', '13:00'),
(4, 4, '2023-06-20', '13:00'),
(4, 4, '2023-06-22', '19:30');

update pacientes set cidade = 'Ilhota' where nome = 'Paulo';

update consultas set dataCons = '2023-07-04' where codm = 1 and codp = 4;
update consultas set hora = '12:00' where codm = 1 and codp = 4;
update pacientes set doenca = 'Sarampo' where nome = 'Ana';

update consultas set hora = '14:30' where codm = 3 and codp = 4;

delete from consultas where codp = 4;
delete from pacientes where codp = 4;

delete from consultas where hora > '19:00';

update medicos set especialidade = 'Clínico Geral' where nome = 'Pedro';
